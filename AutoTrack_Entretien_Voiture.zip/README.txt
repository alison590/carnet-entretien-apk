# AutoTrack — Application d'Entretien Véhicule (Téléphone & Autoradio Android)

## Contenu de l'archive
- `index.html` : Application complète (interface adaptative téléphone/autoradio, vidange complète avec filtres cochés par défaut, alertes km/date, historique modifiable, export PDF et changement de couleur).

## Utilisation rapide
1. Décompressez ce fichier `.zip`.
2. Ouvrez `index.html` dans votre navigateur ou intégrez-le dans le dossier `app/src/main/assets/` de votre projet **Android Studio** (WebView) pour générer votre fichier `.apk`.
